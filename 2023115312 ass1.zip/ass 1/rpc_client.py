import xmlrpc.client

# Replace with your EC2 Public IP
server = xmlrpc.client.ServerProxy("http://16.171.132.55:8000")

print(server.add_student("CS101", "Adhil", 82))
print(server.get_student("CS101"))
print(server.calculate_grade("CS101"))
