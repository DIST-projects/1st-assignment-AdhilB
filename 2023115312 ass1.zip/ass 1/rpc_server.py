from xmlrpc.server import SimpleXMLRPCServer

class StudentService:
    def __init__(self):
        self.students = {}

    def add_student(self, regno, name, marks):
        self.students[regno] = {"name": name, "marks": marks}
        return "Student added successfully"

    def get_student(self, regno):
        return self.students.get(regno, "Student not found")

    def calculate_grade(self, regno):
        if regno not in self.students:
            return "Student not found"
        marks = self.students[regno]["marks"]
        if marks >= 90:
            return "A"
        elif marks >= 75:
            return "B"
        elif marks >= 60:
            return "C"
        else:
            return "Fail"

server = SimpleXMLRPCServer(("0.0.0.0", 8000), allow_none=True)
server.register_instance(StudentService())

print("RPC Server running on port 8000...")
server.serve_forever()
