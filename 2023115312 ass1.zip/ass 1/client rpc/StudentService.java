import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

/*
 * StudentService
 * ---------------
 * Remote interface for Student Management System.
 * Declares methods that can be invoked remotely.
 */
public interface StudentService extends Remote {

    // Add a new student record
    String addStudent(String regNo, String name, int marks)
            throws RemoteException;

    // Retrieve student details
    Map<String, Object> getStudent(String regNo)
            throws RemoteException;

    // Calculate grade for a student
    String calculateGrade(String regNo)
            throws RemoteException;
}
